# RealmForge — Fabric 1.21.1

A lightweight Java 21 Fabric mod source project. The project currently implements a custom parchment/book-style character screen, stats, leveling, energy, skill slots, rank progression, Traits, Perks, a HUD, commands, and JSON player-data persistence.

## Build

The project uses Fabric Loom 1.8.13, Minecraft 1.21.1, Yarn build 3, Fabric Loader 0.16.10, and Fabric API 0.116.6+1.21.1.

### GitHub Actions (Android-friendly)

GitHub Actions is configured in `.github/workflows/build.yml`. To use it, put the **contents** of this project in a GitHub repository so the workflow file is at `.github/workflows/build.yml`, then run **Actions → Build RealmForge → Run workflow**. Download the `RealmForge-Fabric-1.21.1` artifact after a successful run.

GitHub does not discover a workflow stored only inside an unextracted ZIP. If you want to keep the source ZIP intact, first create the workflow file in the repository, then upload the source ZIP and use a ZIP-extraction workflow. A workflow file inside a ZIP cannot trigger itself before it has been committed to the repository.

## Controls

- `K`: open the RealmForge character screen.
- `Z`, `X`, `C`, `V`, `B`, `N`: cast skill slots 1–6.
- `/realmforge help`: show available commands.
- `/realmforge stats`, `/realmforge add <STR|AGI|VIT|INT|ENE>`, `/realmforge slot <1-6> <skill>`, `/realmforge cast <1-6>`.

## Current behavior

- New character records start with 3 Energy. Existing JSON records are loaded and normalized without resetting their level, stats, XP, points, Trait, Perk, or energy value.
- Each of 10 Traits and 10 Perks has an equal 10% selection chance. Rarity is descriptive metadata; it does not change the equal selection weights.
- Trait and Perk selections are only generated if the saved field is empty; there is no reroll command.
- Player data is stored in `realmforge-playerdata.json` in the world save directory and written using a temporary file before replacement.
- The screen is a custom parchment/book-style GUI, **not** Minecraft's literal vanilla Book & Quill editing screen. It uses interactive buttons to support stat upgrades and reference navigation.

## Limitations and test status

This source has not been compiled in this environment because Gradle and dependency downloads are unavailable here. The GitHub Actions workflow is provided to perform a real compile. Do not treat this build as verified until the workflow succeeds and the resulting JAR has been tested in Minecraft 1.21.1. The original JAR/source JAR were not included in the provided upload, so preservation of every original feature cannot be certified. The equipment implementation stores RPG equipment labels and applies simple bonuses; it does not create or equip actual vanilla armor items. Races are not implemented in this source.


Build fix note: gearHp is a double because gearBonus returns double; the GitHub Actions workflow also applies this compatibility fix automatically when building an older ZIP.
