# RealmForge (Fabric 1.21.1, Java 21)

Build: open in IntelliJ (it creates the Gradle wrapper) or run `gradle wrapper --gradle-version 8.8`, then `./gradlew build`.
Jar: `build/libs/realmforge-1.0.0.jar` (client + server; needs Fabric API 0.102.0+1.21.1).

## Use
- **K** opens the RPG book. **Z X C V** use skill slots 1-4.
- `/realmforge book | stats | stat <stat> [n] | skill list | skill bind <slot> <skill> | skill use <slot>`
- Admin (op level 2): `/realmforge admin setlevel|addexp|addpoints|respec|settrait|setperk|reroll|wipe <player> ...`, `admin simulate <n>` (checks rarity odds).

## Rules implemented
- Level: 3 points/level, EXP need x1.2 per level (100 base), cap 100. Start: 5 points, all stats 0.
- STR +2% physical/melee dmg | AGI +1% speed, +0.5% dodge (cap 40%) | VIT +4 HP | INT +3% skill dmg | ENE +10 max energy, +0.1/s regen (base 100 energy, 1/s).
- Rarity odds: Common 50, Uncommon 28, Rare 13, Epic 6, Legendary 2.5, Mythical 0.5 (%). Roll rarity by weight, then pick uniformly within it.
- Trait + perk rolled once on first join; only ops can change them.
- Ranks need level AND kills (see `Rank.java`); never lost.
- Placeholders you can swap: `Rank`, `Skill`, `EquipmentBonuses`, `Trait`, `Perk`.

## Layout
`data/` model + formulas (shared client/server) - `logic/` damage, skills, equipment, attributes - `net/` payloads - `src/client/` HUD, book, keybinds.
