package com.realmforge;

import com.realmforge.data.Perk;
import com.realmforge.data.Rarity;
import com.realmforge.data.Trait;
import com.realmforge.logic.SkillExecutor;
import com.realmforge.net.SkillUsePayload;
import com.realmforge.net.SyncPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RealmForgeMod implements ModInitializer {
    public static final String MOD_ID = "realmforge";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        Rarity.validate(Trait.values(), "Trait");
        Rarity.validate(Perk.values(), "Perk");

        PayloadTypeRegistry.playS2C().register(SyncPayload.ID, SyncPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SkillUsePayload.ID, SkillUsePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SkillUsePayload.ID,
                (payload, ctx) -> ctx.server().execute(() -> SkillExecutor.use(ctx.player(), payload.slot())));

        RpgEvents.register();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> RpgCommands.register(dispatcher));
        LOGGER.info("RealmForge loaded.");
    }
}
