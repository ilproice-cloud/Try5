package com.realmforge.data;

import java.util.Locale;
import static com.realmforge.data.Stat.*;

public enum Trait implements Passive {
    BRAWLER("Brawler", Rarity.COMMON, "Fights first, thinks later.", Effects.of().stat(STR, 2).stat(AGI, -1)),
    BOOKWORM("Bookworm", Rarity.COMMON, "Always has a book nearby.", Effects.of().stat(INT, 2).stat(VIT, -1)),
    QUICK_LEARNER("Quick Learner", Rarity.UNCOMMON, "Learns fast, hits soft.", Effects.of().exp(0.15).dmgOut(-0.05)),
    STEADY_BREATH("Steady Breath", Rarity.UNCOMMON, "Calm and collected.", Effects.of().regen(0.25).stat(STR, -1)),
    IRON_CONSTITUTION("Iron Constitution", Rarity.RARE, "Hard to put down.", Effects.of().stat(VIT, 3).dmgIn(-0.05).stat(AGI, -1)),
    DUELIST("Duelist", Rarity.RARE, "Precise and fragile.", Effects.of().dodge(0.06).dmgOut(0.05).stat(VIT, -2)),
    ARCANE_VESSEL("Arcane Vessel", Rarity.EPIC, "Overflowing with power.", Effects.of().stat(INT, 4).stat(ENE, 3).dmgIn(0.08)),
    BLOODTHIRSTY("Bloodthirsty", Rarity.EPIC, "Heals by hurting.", Effects.of().stat(STR, 3).lifesteal(0.05).dmgIn(0.05)),
    WARBORN("Warborn", Rarity.LEGENDARY, "Born on a battlefield.", Effects.of().stat(STR, 5).stat(VIT, 3).exp(-0.10)),
    WINDWALKER("Windwalker", Rarity.LEGENDARY, "Light as the wind.", Effects.of().stat(AGI, 6).dodge(0.08).stat(VIT, -2)),
    CHOSEN_ONE("Chosen One", Rarity.MYTHICAL, "Fate itself takes notice.", Effects.of().all(3).exp(0.25).dmgOut(0.10).dmgIn(0.10));

    private final String display, desc; private final Rarity rarity; private final Effects fx;
    Trait(String display, Rarity r, String desc, Effects fx) { this.display = display; this.rarity = r; this.desc = desc; this.fx = fx; }

    @Override public String id() { return name().toLowerCase(Locale.ROOT); }
    @Override public String displayName() { return display; }
    @Override public Rarity rarity() { return rarity; }
    @Override public String description() { return desc; }
    @Override public Effects effects() { return fx; }

    public static Trait byId(String id) {
        if (id == null) return null;
        for (Trait t : values()) if (t.id().equalsIgnoreCase(id)) return t;
        return null;
    }
}
