package com.realmforge.data;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** World-saved store keyed by player UUID, so data survives death, relog and restarts. */
public class RpgState extends PersistentState {
    public static final PersistentState.Type<RpgState> TYPE =
            new PersistentState.Type<>(RpgState::new, RpgState::fromNbt, null);

    private final Map<UUID, RpgData> players = new HashMap<>();

    public RpgData get(UUID id) { return players.computeIfAbsent(id, k -> new RpgData()); }
    public void remove(UUID id) { players.remove(id); }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        NbtCompound all = new NbtCompound();
        players.forEach((id, d) -> all.put(id.toString(), d.write()));
        nbt.put("players", all);
        return nbt;
    }

    public static RpgState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        RpgState s = new RpgState();
        NbtCompound all = nbt.getCompound("players");
        for (String key : all.getKeys()) {
            try { s.players.put(UUID.fromString(key), RpgData.read(all.getCompound(key))); }
            catch (IllegalArgumentException ignored) { }
        }
        return s;
    }
}
