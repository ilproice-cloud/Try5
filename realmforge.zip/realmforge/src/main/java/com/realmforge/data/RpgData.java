package com.realmforge.data;

import net.minecraft.nbt.NbtCompound;

/**
 * All per-player RPG data plus every derived-value formula.
 * The SAME class is used on the server (authoritative) and the client (display only),
 * so the book/HUD always show exactly what the server computes.
 */
public final class RpgData {
    public static final int MAX_LEVEL = 100, POINTS_PER_LEVEL = 3, STARTING_POINTS = 5;
    public static final int BASE_ENERGY = 100, HP_PER_VIT = 4, ENERGY_PER_ENE = 10;
    public static final double EXP_GROWTH = 1.20, BASE_EXP = 100;
    public static final double STR_PHYS = 0.02, INT_SKILL = 0.03, AGI_SPEED = 0.01, AGI_DODGE = 0.005, ENE_REGEN = 0.10;

    // ---- persistent ----
    public int level = 1;
    public long exp = 0;
    public int points = STARTING_POINTS;
    public final int[] base = new int[Stat.values().length];
    public float energy = BASE_ENERGY;
    public String traitId = "", perkId = "";
    public int rankIdx = 0, kills = 0;
    public final int[] skillUses = new int[Skill.values().length];
    public final long[] cdEnd = new long[Skill.values().length]; // absolute overworld game time
    public final String[] slots = {"power_strike", "dash", "arcane_bolt", "mend"};

    // ---- runtime / sync-only ----
    public int[] equip = new int[Stat.values().length];
    public int[] cdRemain = new int[Skill.values().length]; // client: ticks left when synced
    public boolean syncDirty;

    // ---------- lookups ----------
    public Trait trait() { return Trait.byId(traitId); }
    public Perk perk() { return Perk.byId(perkId); }
    public boolean initialized() { return trait() != null && perk() != null; }
    public Rank rank() { return Rank.values()[Math.min(rankIdx, Rank.values().length - 1)]; }

    // ---------- stats ----------
    /** Effective stat = allocated + trait + perk + equipment, never below 0. */
    public int stat(Stat s) {
        int i = s.ordinal();
        int v = base[i] + (i < equip.length ? equip[i] : 0);
        Trait t = trait(); if (t != null) v += t.effects().stats[i];
        Perk p = perk(); if (p != null) v += p.effects().stats[i];
        return Math.max(0, v);
    }
    public int bonusOf(Stat s) { return stat(s) - base[s.ordinal()]; }

    private double fx(java.util.function.ToDoubleFunction<Effects> f) {
        double v = 0;
        Trait t = trait(); if (t != null) v += f.applyAsDouble(t.effects());
        Perk p = perk(); if (p != null) v += f.applyAsDouble(p.effects());
        return v;
    }

    // ---------- derived values ----------
    public double physMult() { return 1.0 + STR_PHYS * stat(Stat.STR); }
    public double intSkillMult() { return 1.0 + INT_SKILL * stat(Stat.INT); }
    public double speedBonus() { return Math.min(1.0, AGI_SPEED * stat(Stat.AGI)); }
    public double dodge() { return Math.min(0.40, Math.max(0, AGI_DODGE * stat(Stat.AGI) + fx(e -> e.dodge))); }
    public int maxHealthBonus() { return stat(Stat.VIT) * HP_PER_VIT + (int) fx(e -> e.hp); }
    public double dmgOut() { return Math.max(0.1, 1.0 + fx(e -> e.dmgOut)); }
    public double dmgIn() { return Math.max(0.1, 1.0 + fx(e -> e.dmgIn)); }
    public double expMult() { return Math.max(0.0, 1.0 + fx(e -> e.exp)); }
    public double lifesteal() { return Math.max(0, fx(e -> e.lifesteal)); }
    public double skillBonus() { return Math.max(0.1, 1.0 + fx(e -> e.skillDmg)); }
    public float maxEnergy() {
        double m = Math.max(0.1, 1.0 + fx(e -> e.energy));
        return (float) Math.max(1, (BASE_ENERGY + stat(Stat.ENE) * ENERGY_PER_ENE) * m);
    }
    public double regenPerSecond() {
        double m = Math.max(0.0, 1.0 + fx(e -> e.regen));
        return (1.0 + ENE_REGEN * stat(Stat.ENE)) * m;
    }

    // ---------- exp / levels ----------
    public static long expRequired(int level) { return Math.round(BASE_EXP * Math.pow(EXP_GROWTH, level - 1)); }
    public long expRequired() { return expRequired(level); }

    /** @return number of levels gained. */
    public int addExp(long amount) {
        if (amount <= 0 || level >= MAX_LEVEL) return 0;
        exp += amount;
        int gained = 0;
        while (level < MAX_LEVEL && exp >= expRequired(level)) {
            exp -= expRequired(level);
            level++; points += POINTS_PER_LEVEL; gained++;
        }
        if (level >= MAX_LEVEL) exp = 0;
        syncDirty = true;
        return gained;
    }

    /** Server-side validated spend. */
    public boolean spend(Stat s, int n) {
        if (n < 1 || n > points) return false;
        base[s.ordinal()] += n;
        points -= n;
        syncDirty = true;
        return true;
    }

    // ---------- skills ----------
    public int skillLevel(Skill s) { return Math.min(10, 1 + skillUses[s.ordinal()] / 20); }
    public double skillLevelMult(Skill s) { return 1.0 + 0.05 * (skillLevel(s) - 1); }
    /** Full damage multiplier: skill level, trait/perk skill bonus, INT, and STR for STR skills. */
    public double skillDamageMult(Skill s) {
        double m = skillLevelMult(s) * skillBonus() * intSkillMult();
        if (s.stat == Stat.STR) m *= physMult();
        return m;
    }

    // ---------- NBT ----------
    public NbtCompound write() {
        NbtCompound n = new NbtCompound();
        n.putInt("level", level); n.putLong("exp", exp); n.putInt("points", points);
        n.putIntArray("base", base); n.putFloat("energy", energy);
        n.putString("trait", traitId); n.putString("perk", perkId);
        n.putInt("rank", rankIdx); n.putInt("kills", kills);
        n.putIntArray("uses", skillUses); n.putLongArray("cd", cdEnd);
        for (int i = 0; i < slots.length; i++) n.putString("slot" + i, slots[i]);
        return n;
    }

    public static RpgData read(NbtCompound n) {
        RpgData d = new RpgData();
        if (n.contains("level")) d.level = Math.max(1, Math.min(MAX_LEVEL, n.getInt("level")));
        d.exp = Math.max(0, n.getLong("exp"));
        if (n.contains("points")) d.points = Math.max(0, n.getInt("points"));
        copy(n.getIntArray("base"), d.base);
        if (n.contains("energy")) d.energy = n.getFloat("energy");
        d.traitId = n.getString("trait"); d.perkId = n.getString("perk");
        d.rankIdx = Math.max(0, Math.min(Rank.values().length - 1, n.getInt("rank")));
        d.kills = Math.max(0, n.getInt("kills"));
        copy(n.getIntArray("uses"), d.skillUses);
        long[] cd = n.getLongArray("cd");
        System.arraycopy(cd, 0, d.cdEnd, 0, Math.min(cd.length, d.cdEnd.length));
        for (int i = 0; i < d.slots.length; i++) {
            String s = n.getString("slot" + i);
            if (Skill.byId(s) != null) d.slots[i] = s;
        }
        return d;
    }

    public NbtCompound toSync(long worldTime) {
        NbtCompound n = write();
        n.putIntArray("equip", equip);
        int[] rem = new int[cdEnd.length];
        for (int i = 0; i < rem.length; i++) rem[i] = (int) Math.max(0, cdEnd[i] - worldTime);
        n.putIntArray("cdrem", rem);
        return n;
    }

    public static RpgData fromSync(NbtCompound n) {
        RpgData d = read(n);
        copy(n.getIntArray("equip"), d.equip);
        copy(n.getIntArray("cdrem"), d.cdRemain);
        return d;
    }

    private static void copy(int[] src, int[] dst) { System.arraycopy(src, 0, dst, 0, Math.min(src.length, dst.length)); }
}
