package com.realmforge.data;

/** Shared shape of Traits and Perks. */
public interface Passive {
    String id();
    String displayName();
    Rarity rarity();
    String description();
    Effects effects();
}
