package com.realmforge.data;

import net.minecraft.util.Formatting;
import java.util.*;

/** Six tiers. Weights are explicit and sum to 100 (= percent chance). */
public enum Rarity {
    COMMON("Common", Formatting.GRAY, Formatting.DARK_GRAY, 50.0),
    UNCOMMON("Uncommon", Formatting.GREEN, Formatting.DARK_GREEN, 28.0),
    RARE("Rare", Formatting.BLUE, Formatting.DARK_BLUE, 13.0),
    EPIC("Epic", Formatting.DARK_PURPLE, Formatting.DARK_PURPLE, 6.0),
    LEGENDARY("Legendary", Formatting.GOLD, Formatting.GOLD, 2.5),
    MYTHICAL("Mythical", Formatting.RED, Formatting.DARK_RED, 0.5);

    public final String label;
    /** Colour for chat/HUD (dark backgrounds). */
    public final Formatting color;
    /** Colour for the book (light parchment background). */
    public final Formatting bookColor;
    public final double weight;

    Rarity(String label, Formatting color, Formatting bookColor, double weight) {
        this.label = label; this.color = color; this.bookColor = bookColor; this.weight = weight;
    }

    public static double totalWeight() {
        double t = 0;
        for (Rarity r : values()) t += r.weight;
        return t;
    }

    public double chancePercent() { return weight / totalWeight() * 100.0; }

    /** Weighted roll: x in [0,total), walk the cumulative weights. */
    public static Rarity roll(Random rnd) {
        double x = rnd.nextDouble() * totalWeight(), acc = 0;
        for (Rarity r : values()) {
            acc += r.weight;
            if (x < acc) return r;
        }
        return COMMON;
    }

    /** Roll a rarity by weight, then pick uniformly among entries of that rarity. */
    public static <T extends Passive> T pick(T[] all, Random rnd) {
        Rarity r = roll(rnd);
        List<T> pool = new ArrayList<>();
        for (T t : all) if (t.rarity() == r) pool.add(t);
        if (pool.isEmpty()) throw new IllegalStateException("No entries for rarity " + r);
        return pool.get(rnd.nextInt(pool.size()));
    }

    /** Startup check: every rarity needs at least one entry, otherwise the weights would be a lie. */
    public static void validate(Passive[] all, String what) {
        for (Rarity r : values()) {
            boolean found = false;
            for (Passive p : all) if (p.rarity() == r) { found = true; break; }
            if (!found) throw new IllegalStateException(what + " list has no entry for rarity " + r);
        }
    }
}
