package com.realmforge.data;

import java.util.*;

/** Data-driven bundle of buffs/debuffs used by traits and perks. Negative values are debuffs. */
public final class Effects {
    public final int[] stats = new int[Stat.values().length];
    /** Fractions: 0.05 = +5%. */
    public double dmgOut, dmgIn, exp, regen, energy, dodge, lifesteal, skillDmg;
    public int hp;

    public static Effects of() { return new Effects(); }
    public Effects stat(Stat s, int v) { stats[s.ordinal()] += v; return this; }
    public Effects all(int v) { for (Stat s : Stat.values()) stat(s, v); return this; }
    public Effects dmgOut(double v) { dmgOut = v; return this; }
    public Effects dmgIn(double v) { dmgIn = v; return this; }
    public Effects exp(double v) { exp = v; return this; }
    public Effects regen(double v) { regen = v; return this; }
    public Effects energy(double v) { energy = v; return this; }
    public Effects dodge(double v) { dodge = v; return this; }
    public Effects lifesteal(double v) { lifesteal = v; return this; }
    public Effects skillDmg(double v) { skillDmg = v; return this; }
    public Effects hp(int v) { hp = v; return this; }

    public List<String> buffs() { return lines(true); }
    public List<String> debuffs() { return lines(false); }

    private List<String> lines(boolean good) {
        List<String> out = new ArrayList<>();
        for (Stat s : Stat.values()) {
            int v = stats[s.ordinal()];
            if (v != 0 && (v > 0) == good) out.add(String.format(Locale.ROOT, "%+d %s", v, s.abbr));
        }
        if (hp != 0 && (hp > 0) == good) out.add(String.format(Locale.ROOT, "%+d max HP", hp));
        pct(out, good, dmgOut, true, "dmg dealt");
        pct(out, good, dmgIn, false, "dmg taken");
        pct(out, good, exp, true, "EXP");
        pct(out, good, regen, true, "energy regen");
        pct(out, good, energy, true, "max energy");
        pct(out, good, dodge, true, "dodge");
        pct(out, good, lifesteal, true, "lifesteal");
        pct(out, good, skillDmg, true, "skill dmg");
        return out;
    }

    private static void pct(List<String> out, boolean good, double v, boolean higherIsBetter, String label) {
        if (v == 0) return;
        if (((v > 0) == higherIsBetter) != good) return;
        double p = v * 100.0;
        String num = Math.abs(p - Math.round(p)) < 0.05 ? String.valueOf(Math.round(p)) : String.format(Locale.ROOT, "%.1f", p);
        out.add((p > 0 ? "+" : "") + num + "% " + label);
    }
}
