package com.realmforge.data;

import net.minecraft.util.Formatting;

/** Rank = highest tier whose level AND kill requirements are both met. Ranks are never lost. */
public enum Rank {
    NOVICE("Novice", "o", 1, 0, Formatting.GRAY, Formatting.DARK_GRAY),
    APPRENTICE("Apprentice", "+", 5, 10, Formatting.GREEN, Formatting.DARK_GREEN),
    ADEPT("Adept", "*", 10, 50, Formatting.AQUA, Formatting.DARK_AQUA),
    VETERAN("Veteran", "#", 20, 150, Formatting.BLUE, Formatting.DARK_BLUE),
    ELITE("Elite", "@", 30, 400, Formatting.LIGHT_PURPLE, Formatting.DARK_PURPLE),
    MASTER("Master", "$", 45, 900, Formatting.GOLD, Formatting.GOLD),
    GRANDMASTER("Grandmaster", "&", 65, 2000, Formatting.RED, Formatting.DARK_RED),
    LEGEND("Legend", "%", 90, 5000, Formatting.YELLOW, Formatting.BLACK);

    public final String label, icon;
    public final int minLevel, minKills;
    public final Formatting color, bookColor;

    Rank(String label, String icon, int minLevel, int minKills, Formatting color, Formatting bookColor) {
        this.label = label; this.icon = icon; this.minLevel = minLevel; this.minKills = minKills;
        this.color = color; this.bookColor = bookColor;
    }

    public static Rank forProgress(int level, int kills) {
        Rank best = NOVICE;
        for (Rank r : values()) if (level >= r.minLevel && kills >= r.minKills) best = r;
        return best;
    }

    public Rank next() { return ordinal() + 1 < values().length ? values()[ordinal() + 1] : null; }
}
