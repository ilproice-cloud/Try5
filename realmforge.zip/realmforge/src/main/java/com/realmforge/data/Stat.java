package com.realmforge.data;

import java.util.Locale;

public enum Stat {
    STR("STR", "Strength"), AGI("AGI", "Agility"), VIT("VIT", "Vitality"),
    INT("INT", "Intelligence"), ENE("ENE", "Energy");

    public final String abbr, label;
    Stat(String abbr, String label) { this.abbr = abbr; this.label = label; }
    public String id() { return name().toLowerCase(Locale.ROOT); }
    public static Stat byId(String s) {
        for (Stat st : values()) if (st.id().equalsIgnoreCase(s)) return st;
        return null;
    }
}
