package com.realmforge.net;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> server: "I pressed skill slot N". The server decides everything else. */
public record SkillUsePayload(int slot) implements CustomPayload {
    public static final Id<SkillUsePayload> ID = new Id<>(Identifier.of("realmforge", "skill_use"));
    public static final PacketCodec<ByteBuf, SkillUsePayload> CODEC =
            PacketCodecs.INTEGER.xmap(SkillUsePayload::new, SkillUsePayload::slot);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}
