package com.realmforge.logic;

import com.realmforge.RpgManager;
import com.realmforge.data.*;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Every check (unlock, slot, cooldown, energy) happens here on the server. The client only sends a slot number. */
public final class SkillExecutor {
    private static final double BOLT_RANGE = 24.0;
    private SkillExecutor() { }

    public static void use(ServerPlayerEntity p, int slot) {
        if (slot < 0 || slot >= Skill.SLOTS) return;
        RpgData d = RpgManager.get(p);
        Skill s = Skill.byId(d.slots[slot]);
        if (s == null) { bar(p, "No skill bound to slot " + (slot + 1), Formatting.GRAY); return; }
        if (d.level < s.unlockLevel) { bar(p, s.label + " unlocks at level " + s.unlockLevel, Formatting.RED); return; }
        long now = p.getServerWorld().getTime();
        long left = d.cdEnd[s.ordinal()] - now;
        if (left > 0) { bar(p, s.label + " ready in " + String.format("%.1fs", left / 20.0), Formatting.GRAY); return; }
        if (d.energy < s.energyCost) { bar(p, "Not enough energy (" + s.energyCost + " needed)", Formatting.RED); return; }

        boolean ok = switch (s) {
            case POWER_STRIKE -> powerStrike(p, d, s);
            case DASH -> dash(p, d);
            case ARCANE_BOLT -> arcaneBolt(p, d, s);
            case MEND -> mend(p, d, s);
        };
        if (!ok) return;

        d.energy -= s.energyCost;
        d.cdEnd[s.ordinal()] = now + s.cooldownTicks;
        d.skillUses[s.ordinal()]++;
        d.syncDirty = true;
        RpgManager.sync(p, -1);
    }

    private static void bar(ServerPlayerEntity p, String msg, Formatting f) {
        p.sendMessage(Text.literal(msg).formatted(f), true);
    }

    private static void hurt(ServerPlayerEntity p, LivingEntity target, DamageSource src, double dmg) {
        DamagePipeline.SKILL.set(true);
        try { target.damage(src, (float) dmg); }
        finally { DamagePipeline.SKILL.set(false); }
    }

    private static boolean powerStrike(ServerPlayerEntity p, RpgData d, Skill s) {
        ServerWorld w = p.getServerWorld();
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f);
        LivingEntity best = null; double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(5.0),
                x -> x != p && x.isAlive() && !x.isSpectator())) {
            Vec3d to = e.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist > 4.5 || to.normalize().dotProduct(look) < 0.6) continue;
            if (dist < bestDist) { bestDist = dist; best = e; }
        }
        if (best == null) { bar(p, "No target in front of you", Formatting.GRAY); return false; }
        double dmg = (5.0 + 0.6 * d.stat(Stat.STR)) * d.skillDamageMult(s);
        hurt(p, best, w.getDamageSources().playerAttack(p), dmg);
        Vec3d c = best.getBoundingBox().getCenter();
        w.spawnParticles(ParticleTypes.CRIT, c.x, c.y, c.z, 12, 0.3, 0.3, 0.3, 0.2);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, SoundCategory.PLAYERS, 1f, 0.8f);
        return true;
    }

    private static boolean dash(ServerPlayerEntity p, RpgData d) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d h = new Vec3d(look.x, 0, look.z);
        if (h.lengthSquared() < 1.0E-4) { double yaw = Math.toRadians(p.getYaw()); h = new Vec3d(-Math.sin(yaw), 0, Math.cos(yaw)); }
        double power = Math.min(2.8, 1.4 + 0.03 * d.stat(Stat.AGI));
        h = h.normalize().multiply(power);
        p.setVelocity(h.x, 0.25, h.z);
        p.velocityModified = true;
        p.fallDistance = 0;
        p.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(p));
        p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1f, 1.4f);
        return true;
    }

    private static boolean arcaneBolt(ServerPlayerEntity p, RpgData d, Skill s) {
        ServerWorld w = p.getServerWorld();
        Vec3d start = p.getEyePos(), dir = p.getRotationVec(1.0f);
        Vec3d end = start.add(dir.multiply(BOLT_RANGE));
        BlockHitResult bhr = w.raycast(new RaycastContext(start, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        if (bhr.getType() != HitResult.Type.MISS) end = bhr.getPos();
        Box box = p.getBoundingBox().stretch(dir.multiply(BOLT_RANGE)).expand(1.0);
        EntityHitResult ehr = ProjectileUtil.raycast(p, start, end, box,
                x -> !x.isSpectator() && x.canHit() && x != p, BOLT_RANGE * BOLT_RANGE);
        Vec3d stop = ehr != null ? ehr.getPos() : end;
        double len = start.distanceTo(stop);
        for (double t = 1.0; t < len; t += 0.6) {
            Vec3d pt = start.add(dir.multiply(t));
            w.spawnParticles(ParticleTypes.END_ROD, pt.x, pt.y, pt.z, 1, 0, 0, 0, 0);
        }
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 1f, 1.2f);
        if (ehr != null && ehr.getEntity() instanceof LivingEntity target) {
            double dmg = (4.0 + 0.8 * d.stat(Stat.INT)) * d.skillDamageMult(s);
            hurt(p, target, w.getDamageSources().indirectMagic(p, p), dmg);
        }
        return true;
    }

    private static boolean mend(ServerPlayerEntity p, RpgData d, Skill s) {
        if (p.getHealth() >= p.getMaxHealth()) { bar(p, "Already at full health", Formatting.GRAY); return false; }
        double heal = (4.0 + 0.4 * d.stat(Stat.ENE)) * d.skillLevelMult(s) * d.skillBonus();
        p.heal((float) heal);
        p.getServerWorld().spawnParticles(ParticleTypes.HEART, p.getX(), p.getY() + 1.0, p.getZ(), 6, 0.4, 0.5, 0.4, 0.0);
        p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.6f, 1.6f);
        return true;
    }
}
