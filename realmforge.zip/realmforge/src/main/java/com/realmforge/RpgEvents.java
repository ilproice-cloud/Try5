package com.realmforge;

import com.realmforge.data.RpgData;
import com.realmforge.logic.EquipmentBonuses;
import com.realmforge.logic.StatApplier;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public final class RpgEvents {
    private RpgEvents() { }

    public static void register() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> onJoin(handler.getPlayer()));

        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            RpgData d = RpgManager.get(newPlayer);
            d.equip = EquipmentBonuses.compute(newPlayer);
            StatApplier.apply(newPlayer, d, false);
            if (!alive) newPlayer.setHealth(newPlayer.getMaxHealth());
            RpgManager.sync(newPlayer, -1);
        });

        // Dodge: server-authoritative, cancels the hit entirely.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!(entity instanceof ServerPlayerEntity vp)) return true;
            if (source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)) return true;
            if (source.getAttacker() == null && !source.isIn(DamageTypeTags.IS_PROJECTILE)) return true;
            double chance = RpgManager.get(vp).dodge();
            if (chance > 0 && ThreadLocalRandom.current().nextDouble() < chance) {
                vp.sendMessage(Text.literal("Dodged!").formatted(Formatting.AQUA), true);
                vp.getServerWorld().spawnParticles(ParticleTypes.CLOUD, vp.getX(), vp.getY() + 1, vp.getZ(), 6, 0.3, 0.4, 0.3, 0.02);
                return false;
            }
            return true;
        });

        // EXP + kills
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof PlayerEntity) return;
            if (!(source.getAttacker() instanceof ServerPlayerEntity p)) return;
            RpgData d = RpgManager.get(p);
            double base = entity.getMaxHealth() * 0.6;
            base *= (entity instanceof HostileEntity) ? 1.5 : 0.5;
            d.kills++;
            RpgManager.award(p, d, Math.max(1, Math.round(base * d.expMult())));
        });

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (!(player instanceof ServerPlayerEntity p)) return;
            String path = Registries.BLOCK.getId(state.getBlock()).getPath();
            long exp = 0;
            if (path.endsWith("_ore") || path.equals("ancient_debris")) exp = 4;
            else if (state.isIn(BlockTags.LOGS)) exp = 1;
            if (exp > 0) {
                RpgData d = RpgManager.get(p);
                RpgManager.award(p, d, Math.max(1, Math.round(exp * d.expMult())));
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(RpgEvents::tick);
    }

    private static void onJoin(ServerPlayerEntity p) {
        RpgData d = RpgManager.get(p);
        boolean fresh = !d.initialized();
        if (fresh) RpgManager.initialize(p, d);
        d.equip = EquipmentBonuses.compute(p);
        StatApplier.apply(p, d, false);
        RpgManager.checkRank(p, d, false);
        RpgManager.sync(p, -1);
        if (fresh) {
            p.sendMessage(Text.literal("Welcome to RealmForge! Your permanent Trait and Perk have been chosen.")
                    .formatted(Formatting.GOLD), false);
            p.sendMessage(Text.literal("Press K (or /realmforge book) to open your RPG book. Skills: Z X C V.")
                    .formatted(Formatting.YELLOW), false);
        }
    }

    private static void tick(MinecraftServer server) {
        int t = server.getTicks();
        if (t % 10 != 0) return;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            RpgData d = RpgManager.get(p);
            if (!d.initialized()) continue;

            // equipment (recomputed from scratch -> no duplicate bonuses)
            int[] eq = EquipmentBonuses.compute(p);
            if (!Arrays.equals(eq, d.equip)) {
                d.equip = eq;
                StatApplier.apply(p, d, false);
            }

            // energy regen (called every 10 ticks = 0.5s)
            float max = d.maxEnergy();
            if (d.energy < max) {
                d.energy = Math.min(max, d.energy + (float) (d.regenPerSecond() * 0.5));
                d.syncDirty = true;
            } else if (d.energy > max) {
                d.energy = max;
                d.syncDirty = true;
            }

            RpgManager.checkRank(p, d, true);
            if (d.syncDirty) RpgManager.sync(p, -1);
        }
        if (t % 200 == 0) RpgManager.state(server).markDirty();
    }
}
