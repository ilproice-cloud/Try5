package com.realmforge.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.BookScreen;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import net.minecraft.util.Identifier;

/**
 * Vanilla BookScreen drawn at up to 230% (capped so it always fits the window), with no background blur.
 * Links whose value starts with "rf:" switch between the main book and the trait/perk books, so the
 * trait/perk pages can only be reached through the TRAIT / PERK buttons (arrows never lead into them).
 */
public class RpgBookScreen extends BookScreen {
    public static final float TARGET_SCALE = 2.3f;
    private static final Identifier BOOK_TEXTURE = Identifier.ofVanilla("textures/gui/book.png");

    private final int startPage;
    private float scale = 1f;

    public RpgBookScreen(BookScreen.Contents contents, int startPage) {
        super(contents);
        this.startPage = startPage;
    }

    @Override
    public void init(MinecraftClient client, int width, int height) {
        this.scale = Math.max(1f, Math.min(TARGET_SCALE, height / 200f));
        // Lay the book out in a smaller "virtual" window, then scale it up when drawing.
        super.init(client, Math.round(width / scale), Math.round(height / scale));
    }

    @Override
    protected void init() {
        super.init();
        if (startPage > 0) this.setPage(startPage);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.getMatrices().push();
        ctx.getMatrices().scale(scale, scale, 1f);
        super.render(ctx, (int) (mouseX / scale), (int) (mouseY / scale), delta);
        ctx.getMatrices().pop();
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderInGameBackground(ctx);                      // plain dim, no blur
        int x = (this.width - 192) / 2;
        ctx.drawTexture(BOOK_TEXTURE, x, 2, 0, 0, 192, 192);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return super.mouseClicked(mouseX / scale, mouseY / scale, button);
    }

    @Override
    public boolean handleTextClick(Style style) {
        ClickEvent ev = style == null ? null : style.getClickEvent();
        if (ev != null && ev.getAction() == ClickEvent.Action.CHANGE_PAGE && ev.getValue().startsWith("rf:")) {
            if (this.client != null) {
                switch (ev.getValue()) {
                    case "rf:traits" -> this.client.setScreen(RpgBook.traits());
                    case "rf:perks" -> this.client.setScreen(RpgBook.perks());
                    default -> this.client.setScreen(RpgBook.main(3)); // back to References
                }
            }
            return true;
        }
        return super.handleTextClick(style);
    }
}
