package com.realmforge.client;

import com.realmforge.net.SkillUsePayload;
import com.realmforge.net.SyncPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

public class RealmForgeClient implements ClientModInitializer {
    private static final String CAT = "key.categories.realmforge";
    public static final KeyBinding OPEN = new KeyBinding("key.realmforge.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, CAT);
    public static final KeyBinding[] SKILL_KEYS = {
            new KeyBinding("key.realmforge.skill1", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, CAT),
            new KeyBinding("key.realmforge.skill2", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, CAT),
            new KeyBinding("key.realmforge.skill3", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, CAT),
            new KeyBinding("key.realmforge.skill4", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, CAT)
    };

    @Override
    public void onInitializeClient() {
        KeyBindingHelper.registerKeyBinding(OPEN);
        for (KeyBinding k : SKILL_KEYS) KeyBindingHelper.registerKeyBinding(k);

        ClientPlayNetworking.registerGlobalReceiver(SyncPayload.ID, (payload, ctx) -> ctx.client().execute(() -> {
            ClientRpg.accept(payload.snbt());
            if (payload.openPage() >= 0 && ClientRpg.data != null) ctx.client().setScreen(RpgBook.screen(payload.openPage()));
        }));

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientRpg.data = null);
        HudRenderCallback.EVENT.register(RpgHud::render);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            ClientRpg.tick++;
            if (mc.player == null) return;
            while (OPEN.wasPressed()) {
                if (mc.currentScreen != null) continue;
                if (ClientRpg.data == null) mc.player.sendMessage(Text.literal("RealmForge data not loaded yet.").formatted(Formatting.RED), true);
                else mc.setScreen(RpgBook.screen(0));
            }
            for (int i = 0; i < SKILL_KEYS.length; i++) {
                while (SKILL_KEYS[i].wasPressed()) {
                    if (mc.currentScreen == null) ClientPlayNetworking.send(new SkillUsePayload(i));
                }
            }
        });
    }
}
