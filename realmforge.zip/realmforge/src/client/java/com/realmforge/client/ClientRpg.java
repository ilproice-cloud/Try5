package com.realmforge.client;

import com.realmforge.data.RpgData;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.StringNbtReader;

/** Client-side mirror of the server's data. Display only; the server is authoritative. */
public final class ClientRpg {
    public static RpgData data;
    public static long tick;      // client ticks since start
    public static long recvTick;  // tick at which cooldown values were received
    private ClientRpg() { }

    public static void accept(String snbt) {
        try {
            NbtCompound n = StringNbtReader.parse(snbt);
            data = RpgData.fromSync(n);
            recvTick = tick;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int cooldownLeft(int skillOrdinal) {
        if (data == null) return 0;
        return (int) Math.max(0, data.cdRemain[skillOrdinal] - (tick - recvTick));
    }
}
