package com.realmforge.client;

import com.realmforge.data.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class RpgHud {
    private RpgHud() { }

    public static void render(DrawContext g, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        RpgData d = ClientRpg.data;
        if (d == null || mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;

        int x = 8, y = 8, w = 156;
        g.fill(x - 4, y - 4, x + w + 4, y + 90, 0x90000000);

        Rank r = d.rank();
        g.drawTextWithShadow(tr, Text.literal("[" + r.icon + "] " + mc.player.getName().getString()).formatted(r.color), x, y, 0xFFFFFF);
        Text lv = Text.literal("Lv." + d.level).formatted(Formatting.YELLOW);
        g.drawTextWithShadow(tr, lv, x + w - tr.getWidth(lv), y, 0xFFFFFF);
        y += 11;
        g.drawTextWithShadow(tr, Text.literal(r.label).formatted(Formatting.GRAY), x, y, 0xFFFFFF);
        if (d.points > 0) {
            Text pts = Text.literal("+" + d.points + " pts [K]").formatted(Formatting.GOLD);
            g.drawTextWithShadow(tr, pts, x + w - tr.getWidth(pts), y, 0xFFFFFF);
        }
        y += 12;

        float hp = mc.player.getHealth(), maxHp = mc.player.getMaxHealth();
        bar(g, tr, x, y, w, hp / Math.max(1f, maxHp), 0xFFC62828, String.format("HP %.0f / %.0f", hp, maxHp));
        y += 12;
        float maxE = d.maxEnergy();
        bar(g, tr, x, y, w, d.energy / Math.max(1f, maxE), 0xFF1E78D2, String.format("EN %.0f / %.0f", d.energy, maxE));
        y += 12;
        boolean max = d.level >= RpgData.MAX_LEVEL;
        bar(g, tr, x, y, w, max ? 1f : (float) d.exp / Math.max(1, d.expRequired()), 0xFF2E9E3F,
                max ? "EXP MAX" : "EXP " + d.exp + " / " + d.expRequired());
        y += 14;

        int cw = (w - 6) / 4;
        for (int i = 0; i < Skill.SLOTS; i++) {
            int cx = x + i * (cw + 2);
            Skill s = Skill.byId(d.slots[i]);
            String key = RealmForgeClient.SKILL_KEYS[i].getBoundKeyLocalizedText().getString();
            int bg = 0xFF2A2A2A; String second = ""; int col = 0xFFFFFF;
            if (s == null) { second = "-"; }
            else if (d.level < s.unlockLevel) { bg = 0xFF1A1A1A; second = "Lv" + s.unlockLevel; col = 0x888888; }
            else {
                int cd = ClientRpg.cooldownLeft(s.ordinal());
                if (cd > 0) { bg = 0xFF5A1414; second = String.format("%.1fs", cd / 20.0); }
                else if (d.energy < s.energyCost) { bg = 0xFF3A3A14; second = s.energyCost + "en"; col = 0xFFDD66; }
                else second = tr.trimToWidth(s.label, cw - 2);
            }
            g.fill(cx, y, cx + cw, y + 19, bg);
            g.drawTextWithShadow(tr, Text.literal(key), cx + 2, y + 1, 0xAAAAAA);
            g.drawTextWithShadow(tr, Text.literal(second), cx + 2, y + 10, col);
        }
    }

    private static void bar(DrawContext g, TextRenderer tr, int x, int y, int w, float frac, int color, String label) {
        frac = Math.max(0f, Math.min(1f, frac));
        g.fill(x, y, x + w, y + 11, 0xFF1C1C1C);
        g.fill(x, y, x + (int) (w * frac), y + 11, color);
        g.drawCenteredTextWithShadow(tr, Text.literal(label), x + w / 2, y + 2, 0xFFFFFF);
    }
}
