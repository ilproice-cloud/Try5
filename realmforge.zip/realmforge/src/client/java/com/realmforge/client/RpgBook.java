package com.realmforge.client;

import com.realmforge.data.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.BookScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.WrittenBookContentComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.*;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Builds the 4 core pages (Player, Attributes, Stat Effects, References) plus the Trait/Perk
 * encyclopedia sub-pages, then shows them in the vanilla book screen.
 */
public final class RpgBook {
    private static final int PER_PAGE = 2;
    private RpgBook() { }

    public static Screen screen(int startPage) {
        RpgData d = ClientRpg.data;
        String name = MinecraftClient.getInstance().player != null
                ? MinecraftClient.getInstance().player.getName().getString() : "Player";
        List<RawFilteredPair<Text>> raw = new ArrayList<>();
        for (Text t : pages(d, name)) raw.add(RawFilteredPair.of(t));
        ItemStack stack = new ItemStack(Items.WRITTEN_BOOK);
        stack.set(DataComponentTypes.WRITTEN_BOOK_CONTENT,
                new WrittenBookContentComponent(RawFilteredPair.of("RealmForge"), "RealmForge", 0, raw, true));
        return new RpgBookScreen(BookScreen.Contents.create(stack), startPage);
    }

    // ------------------------------------------------------------------ pages
    public static List<Text> pages(RpgData d, String name) {
        int traitPages = (int) Math.ceil(Trait.values().length / (double) PER_PAGE);
        int traitStart = 5;                 // 1-based book page numbers
        int perkStart = traitStart + traitPages;

        List<Text> pages = new ArrayList<>();
        pages.add(playerPage(d, name));
        pages.add(attributesPage(d));
        pages.add(effectsPage(d));
        pages.add(referencesPage(d, traitStart, perkStart));
        passivePages(pages, "TRAITS", Trait.values(), d.traitId);
        passivePages(pages, "PERKS", Perk.values(), d.perkId);
        return pages;
    }

    // Page 1 - Player
    private static Text playerPage(RpgData d, String name) {
        Rank r = d.rank();
        Trait t = d.trait(); Perk p = d.perk();
        MutableText m = Text.empty();
        m.append(t("PLAYER\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        m.append(t("[" + r.icon + "] " + name + "\n", Formatting.BOLD, Formatting.BLACK));
        m.append(t("Rank: ", Formatting.DARK_GRAY)).append(t(r.label + "\n", Formatting.BOLD, r.bookColor));
        m.append(t("Level: ", Formatting.DARK_GRAY)).append(t(d.level + "\n", Formatting.BLACK));
        m.append(t("EXP: ", Formatting.DARK_GRAY)).append(t(d.level >= RpgData.MAX_LEVEL ? "MAX\n" : d.exp + " / " + d.expRequired() + "\n", Formatting.BLACK));
        Rank nx = r.next();
        if (nx != null) m.append(t("Next: " + nx.label + " (Lv" + nx.minLevel + ", " + nx.minKills + " kills; you: " + d.kills + ")\n", Formatting.GRAY));
        m.append(t("\nTrait: ", Formatting.DARK_GRAY));
        if (t != null) m.append(t(t.displayName(), t.rarity().bookColor, Formatting.BOLD)).append(t(" (" + t.rarity().label + ")\n", t.rarity().bookColor));
        m.append(t("Perk: ", Formatting.DARK_GRAY));
        if (p != null) m.append(t(p.displayName(), p.rarity().bookColor, Formatting.BOLD)).append(t(" (" + p.rarity().label + ")\n", p.rarity().bookColor));
        m.append(t("\nStat points: ", Formatting.DARK_GRAY)).append(t(String.valueOf(d.points), d.points > 0 ? Formatting.DARK_GREEN : Formatting.BLACK, Formatting.BOLD));
        return m;
    }

    // Page 2 - Attributes with working buttons
    private static Text attributesPage(RpgData d) {
        MutableText m = Text.empty();
        m.append(t("ATTRIBUTES\n\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        for (Stat s : Stat.values()) {
            int bonus = d.bonusOf(s);
            m.append(t(s.abbr + " ", Formatting.BOLD, Formatting.BLACK));
            m.append(t(String.valueOf(d.stat(s)), Formatting.BLACK));
            if (bonus != 0) m.append(t(" (" + (bonus > 0 ? "+" : "") + bonus + ")", bonus > 0 ? Formatting.DARK_GREEN : Formatting.DARK_RED));
            m.append(Text.literal("  "));
            if (d.points >= 1) m.append(button("[+1]", "/realmforge ui upgrade " + s.id() + " 1", Formatting.DARK_GREEN, "Spend 1 point on " + s.label));
            else m.append(t("[+1]", Formatting.GRAY));
            if (d.points >= 5) m.append(Text.literal(" ")).append(button("[+5]", "/realmforge ui upgrade " + s.id() + " 5", Formatting.DARK_GREEN, "Spend 5 points on " + s.label));
            m.append(Text.literal("\n\n"));
        }
        m.append(t("Points left: ", Formatting.DARK_GRAY)).append(t(String.valueOf(d.points), d.points > 0 ? Formatting.DARK_GREEN : Formatting.BLACK, Formatting.BOLD));
        m.append(t("\n(+n) = trait/perk/equipment", Formatting.GRAY));
        return m;
    }

    // Page 3 - exact bonuses
    private static Text effectsPage(RpgData d) {
        MutableText m = Text.empty();
        m.append(t("STAT EFFECTS\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        line(m, "STR " + d.stat(Stat.STR), "+" + pct(d.physMult() - 1) + " physical & melee dmg");
        line(m, "AGI " + d.stat(Stat.AGI), "+" + pct(d.speedBonus()) + " speed, " + pct(d.dodge()) + " dodge");
        line(m, "VIT " + d.stat(Stat.VIT), "+" + d.maxHealthBonus() + " max HP (" + (20 + d.maxHealthBonus()) + " total)");
        line(m, "INT " + d.stat(Stat.INT), "+" + pct(d.intSkillMult() - 1) + " magic & skill dmg");
        line(m, "ENE " + d.stat(Stat.ENE), (int) d.maxEnergy() + " max energy, +" + String.format(Locale.ROOT, "%.1f", d.regenPerSecond()) + "/s");
        m.append(t("Per point: STR 2% dmg, AGI 1% speed / 0.5% dodge, VIT 4 HP, INT 3% skill dmg, ENE 10 energy + 0.1/s", Formatting.GRAY));
        return m;
    }

    // Page 4 - references hub
    private static Text referencesPage(RpgData d, int traitStart, int perkStart) {
        Trait t = d.trait(); Perk p = d.perk();
        MutableText m = Text.empty();
        m.append(t("REFERENCES\n\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        m.append(pageLink("[ TRAIT ]", traitStart, Formatting.DARK_AQUA, "Open the trait list")).append(Text.literal("   "));
        m.append(pageLink("[ PERK ]", perkStart, Formatting.DARK_AQUA, "Open the perk list")).append(Text.literal("\n\n"));
        m.append(t("Your trait:\n", Formatting.DARK_GRAY));
        if (t != null) m.append(t(t.displayName() + " (" + t.rarity().label + ")\n\n", t.rarity().bookColor, Formatting.BOLD));
        m.append(t("Your perk:\n", Formatting.DARK_GRAY));
        if (p != null) m.append(t(p.displayName() + " (" + p.rarity().label + ")\n\n", p.rarity().bookColor, Formatting.BOLD));
        m.append(t("Both are permanent.", Formatting.GRAY));
        return m;
    }

    // Trait / Perk encyclopedia pages
    private static void passivePages(List<Text> pages, String title, Passive[] all, String selectedId) {
        int count = (int) Math.ceil(all.length / (double) PER_PAGE);
        for (int pg = 0; pg < count; pg++) {
            MutableText m = Text.empty();
            m.append(pageLink("[<4]", 4, Formatting.DARK_AQUA, "Back to references"));
            m.append(t(" " + title + " " + (pg + 1) + "/" + count + "\n", Formatting.BOLD, Formatting.DARK_PURPLE));
            for (int i = pg * PER_PAGE; i < Math.min(all.length, (pg + 1) * PER_PAGE); i++) {
                Passive p = all[i];
                boolean mine = p.id().equalsIgnoreCase(selectedId);
                Formatting rc = p.rarity().bookColor;
                MutableText head = t((mine ? "\u2605 " : "") + p.displayName() + " (" + p.rarity().label + ")",
                        rc, Formatting.BOLD);
                if (mine) head.formatted(Formatting.UNDERLINE);
                m.append(head).append(Text.literal("\n"));
                m.append(t(p.description() + "\n", Formatting.GRAY));
                List<String> buffs = p.effects().buffs(), debuffs = p.effects().debuffs();
                if (!buffs.isEmpty()) m.append(t(String.join(", ", buffs) + "\n", Formatting.DARK_GREEN));
                if (!debuffs.isEmpty()) m.append(t(String.join(", ", debuffs) + "\n", Formatting.DARK_RED));
                if (mine) m.append(t("<< YOURS (permanent)\n", Formatting.GOLD, Formatting.BOLD));
                m.append(Text.literal("\n"));
            }
            pages.add(m);
        }
    }

    // ------------------------------------------------------------------ helpers
    private static void line(MutableText m, String head, String body) {
        m.append(t("\n" + head + "\n", Formatting.BOLD, Formatting.BLACK));
        m.append(t(body + "\n", Formatting.DARK_GREEN));
    }

    private static String pct(double v) {
        double p = v * 100;
        return (Math.abs(p - Math.round(p)) < 0.05 ? String.valueOf(Math.round(p)) : String.format(Locale.ROOT, "%.1f", p)) + "%";
    }

    private static MutableText t(String s, Formatting... f) { return Text.literal(s).formatted(f); }

    private static MutableText button(String label, String command, Formatting color, String hover) {
        return Text.literal(label).setStyle(Style.EMPTY.withColor(color).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, command))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal(hover))));
    }

    private static MutableText pageLink(String label, int page1Based, Formatting color, String hover) {
        return Text.literal(label).setStyle(Style.EMPTY.withColor(color).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.CHANGE_PAGE, String.valueOf(page1Based)))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal(hover))));
    }
}
