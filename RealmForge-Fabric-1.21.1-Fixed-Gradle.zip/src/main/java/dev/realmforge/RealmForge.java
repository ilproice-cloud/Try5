package dev.realmforge;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.WorldSavePath;

import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class RealmForge implements ModInitializer {
    public static final String MOD_ID = "realmforge";
    private static final Gson GSON = new GsonBuilder().create();
    private static final Type STORE_TYPE = new TypeToken<Map<String, PlayerData>>() {}.getType();
    private static final Map<UUID, PlayerData> DATA = new HashMap<>();
    private static Path dataFile;
    private static int tickCounter;
    private static int saveCounter;

    public static final String[] TRAITS = {"Battle Instinct", "Iron Will", "Arcane Soul", "Swift Current", "Vital Core", "Mana Conduit", "Predator's Focus", "Unbreakable", "Lucky Star", "Duelist's Edge"};
    public static final String[] PERKS = {"Fast Learner", "Second Wind", "Energy Saver", "Heavy Hitter", "Fleet Footed", "Deep Reserves", "Guardian", "Keen Eye", "Overcharger", "Survivor"};
    public static final String[] SKILLS = {"burst", "focus", "dash", "nova", "heal", "guard"};

    @Override public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(RealmForgeSyncPayload.ID, RealmForgeSyncPayload.CODEC);
        ServerLifecycleEvents.SERVER_STARTED.register(RealmForge::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(RealmForge::save);
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            PlayerData d = get(handler.player);
            if (d.trait == null || d.trait.isBlank()) d.trait = choose(TRAITS);
            if (d.perk == null || d.perk.isBlank()) d.perk = choose(PERKS);
            normalizeRank(d);
            applyAttributes(handler.player, d);
            save(server); sync(handler.player);
            handler.player.sendMessage(Text.literal("§6[RealmForge] §fCharacter initialized. Press K to open your character book."), false);
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> save(server));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++saveCounter >= 600) { saveCounter = 0; save(server); }
            if (++tickCounter >= 20) {
                tickCounter = 0;
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    PlayerData d = get(p);
                    int regen = 1 + d.stats.get("ENE") / 20 + (d.trait.equals("Mana Conduit") ? 1 : 0) + (d.perk.equals("Overcharger") ? 1 : 0);
                    if (d.trait.equals("Battle Instinct")) regen = Math.max(0, regen - 1);
                    if (d.perk.equals("Second Wind") || d.perk.equals("Survivor")) regen = Math.max(0, regen - 1);
                    d.energy = Math.min(d.maxEnergy(), d.energy + regen);
                    if (d.perk.equals("Second Wind") && d.secondWindCooldown <= 0 && p.getHealth() <= p.getMaxHealth() * 0.30f) {
                        p.heal(5.0f); d.secondWindCooldown = 60;
                    }
                    if (d.secondWindCooldown > 0) d.secondWindCooldown--;
                    if (d.trait.equals("Unbreakable") && p.getHealth() < p.getMaxHealth() * 0.25f && p.age % 40 == 0) p.heal(1.0f);
                    applyAttributes(p, d);
                    sync(p);
                }
            }
        });
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (!(entity instanceof ServerPlayerEntity p) || amount <= 0) return true;
            PlayerData d = get(p);
            double chance = Math.min(0.35, d.stats.get("AGI") * 0.00001);
            if (d.trait.equals("Swift Current")) chance += 0.08;
            if (d.trait.equals("Iron Will")) chance += 0.05;
            if (d.trait.equals("Unbreakable")) chance += 0.07;
            if (d.perk.equals("Fleet Footed")) chance += 0.05;
            if (d.perk.equals("Guardian")) chance += 0.05;
            return ThreadLocalRandom.current().nextDouble() >= Math.min(0.55, chance);
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (source.getAttacker() instanceof ServerPlayerEntity p && entity != p) {
                PlayerData d = get(p);
                double xpMultiplier = d.perk.equals("Fast Learner") ? 1.20 : 1.0;
                if (d.trait.equals("Lucky Star")) xpMultiplier += 0.05;
                d.xp += Math.max(5, (int)Math.ceil(entity.getMaxHealth() * 2 * xpMultiplier));
                while (d.xp >= d.xpToNext()) { d.xp -= d.xpToNext(); d.level++; d.statPoints += 3; }
                normalizeRank(d);
                if (d.perk.equals("Survivor")) p.heal(2.0f);
                save(p.getServer()); sync(p);
            }
        });
        AttackEntityCallback.EVENT.register((player, world, hand, target, hit) -> {
            if (!world.isClient && player instanceof ServerPlayerEntity p && target instanceof LivingEntity living && living.isAlive()) {
                PlayerData d = get(p);
                double bonus = d.stats.get("STR") * 1.0;
                if (d.trait.equals("Battle Instinct")) bonus += 2.0;
                if (d.trait.equals("Duelist's Edge")) bonus += 1.5;
                if (d.trait.equals("Predator's Focus") && living.getHealth() <= living.getMaxHealth() * 0.5f) bonus += 2.0;
                if (d.perk.equals("Heavy Hitter")) bonus += 2.0;
                if (d.perk.equals("Keen Eye")) bonus += 0.75;
                bonus += gearBonus(d.equipment.getOrDefault("weapon", "None"));
                if (d.trait.equals("Swift Current") || d.trait.equals("Lucky Star") || d.perk.equals("Fast Learner") || d.perk.equals("Energy Saver") || d.perk.equals("Deep Reserves")) bonus *= 0.90;
                if (bonus > 0) living.damage(p.getDamageSources().playerAttack(p), (float)bonus);
            }
            return ActionResult.PASS;
        });
        registerCommands();
    }

    private static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
            literal("realmforge")
                .then(literal("book").executes(ctx -> { if (ctx.getSource().getEntity() instanceof ServerPlayerEntity p) { sync(p); p.sendMessage(Text.literal("§6Open the character book with K."), false); return 1; } return 0; }))
                .then(literal("stats").executes(ctx -> showStats(ctx.getSource())))
                .then(literal("info").executes(ctx -> showInfo(ctx.getSource())))
                .then(literal("add").then(argument("stat", StringArgumentType.word()).executes(ctx -> addStat(ctx.getSource(), StringArgumentType.getString(ctx, "stat")))))
                .then(literal("skill").then(argument("skill", StringArgumentType.word()).executes(ctx -> useSkill(ctx.getSource(), StringArgumentType.getString(ctx, "skill")))))
                .then(literal("cast").then(argument("slot", IntegerArgumentType.integer(1, 6)).executes(ctx -> castSlot(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "slot")))))
                .then(literal("slot").then(argument("slot", IntegerArgumentType.integer(1, 6)).then(argument("skill", StringArgumentType.word()).executes(ctx -> setSlot(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "slot"), StringArgumentType.getString(ctx, "skill"))))))
                .then(literal("rank").executes(ctx -> showRank(ctx.getSource())))
                .then(literal("equipment").executes(ctx -> showEquipment(ctx.getSource())))
                .then(literal("equip").then(argument("slot", StringArgumentType.word()).then(argument("item", StringArgumentType.word()).executes(ctx -> equip(ctx.getSource(), StringArgumentType.getString(ctx, "slot"), StringArgumentType.getString(ctx, "item"))))))
                .then(literal("mastery").executes(ctx -> showMastery(ctx.getSource())))
                .then(literal("help").executes(ctx -> { ctx.getSource().sendFeedback(() -> Text.literal("§6RealmForge: §e/realmforge stats§7, §e/realmforge add <STR|AGI|VIT|INT|ENE>§7, §e/realmforge skill <burst|focus|dash|nova|heal|guard>§7, §e/realmforge slot <1-6> <skill>§7, §e/realmforge cast <1-6>§7, §e/realmforge equip <pant|shirt|hat|shoes|weapon> <item>§7, §e/realmforge equipment§7, §e/realmforge mastery§7, §e/realmforge info"), false); return 1; }))
        ));
    }

    private static int showStats(ServerCommandSource source) {
        if (!(source.getEntity() instanceof ServerPlayerEntity p)) { source.sendError(Text.literal("Players only.")); return 0; }
        PlayerData d = get(p);
        source.sendFeedback(() -> Text.literal("§6§lREALMFORGE §7— §f" + p.getName().getString() + "\n§eLevel: §f" + d.level + " §7| §eRank: §f" + d.rank + "\n§cHP: §f" + (int)p.getHealth() + "/" + (int)p.getMaxHealth() + " §bEnergy: §f" + d.energy + "/" + d.maxEnergy() + "\n§aEXP: §f" + d.xp + "/" + d.xpToNext() + " §dPoints: §f" + d.statPoints + "\n§fSTR " + d.stats.get("STR") + " | AGI " + d.stats.get("AGI") + " | VIT " + d.stats.get("VIT") + " | INT " + d.stats.get("INT") + " | ENE " + d.stats.get("ENE") + "\n§6Trait: §f" + d.trait + " §dPerk: §f" + d.perk), false);
        sync(p); return 1;
    }

    private static int showRank(ServerCommandSource source) {
        if (!(source.getEntity() instanceof ServerPlayerEntity p)) return 0;
        PlayerData d = get(p); source.sendFeedback(() -> Text.literal("§6Rank: §f" + d.rank + " §7(Level " + d.level + ")"), false); return 1;
    }

    private static int showInfo(ServerCommandSource source) {
        source.sendFeedback(() -> Text.literal("§6RealmForge character book§7: press K.\n§aSTR: melee bonus; AGI: movement/dodge; VIT: maximum health; INT: skill power; ENE: capacity/regeneration.\n§eEvery level grants 3 stat points. Mobs grant EXP. Traits and perks are permanent.\n§bSkills: burst, focus, dash, nova, heal, guard. Bind them using /realmforge slot <1-6> <skill>."), false); return 1;
    }

    private static int addStat(ServerCommandSource source, String raw) {
        if (!(source.getEntity() instanceof ServerPlayerEntity p)) return 0;
        String stat = raw.toUpperCase(Locale.ROOT);
        if (!Set.of("STR", "AGI", "VIT", "INT", "ENE").contains(stat)) { source.sendError(Text.literal("Use STR, AGI, VIT, INT or ENE.")); return 0; }
        PlayerData d = get(p); if (d.statPoints <= 0) { source.sendError(Text.literal("No stat points available.")); return 0; }
        d.statPoints--; d.stats.put(stat, d.stats.get(stat) + 1);
        applyAttributes(p, d);
        if (stat.equals("VIT")) p.setHealth(Math.min(p.getMaxHealth(), p.getHealth() + 4));
        if (stat.equals("ENE")) d.energy = d.maxEnergy();
        save(p.getServer()); sync(p); source.sendFeedback(() -> Text.literal("§a+1 " + stat + " §7| points remaining: " + d.statPoints), false); return 1;
    }

    private static int setSlot(ServerCommandSource source, int slot, String raw) {
        if (!(source.getEntity() instanceof ServerPlayerEntity p)) return 0;
        String skill = raw.toLowerCase(Locale.ROOT);
        if (!Arrays.asList(SKILLS).contains(skill)) { source.sendError(Text.literal("Skill must be burst, focus, dash, nova, heal, or guard.")); return 0; }
        PlayerData d = get(p); d.skillSlots.set(slot - 1, skill); save(p.getServer()); sync(p);
        source.sendFeedback(() -> Text.literal("§aSlot " + slot + " set to " + skill), false); return 1;
    }

    private static int castSlot(ServerCommandSource source, int slot) {
        if (!(source.getEntity() instanceof ServerPlayerEntity p)) return 0;
        return useSkill(source, get(p).skillSlots.get(slot - 1));
    }

    private static int showEquipment(ServerCommandSource source) {
        if (!(source.getEntity() instanceof ServerPlayerEntity p)) return 0;
        PlayerData d = get(p);
        source.sendFeedback(() -> Text.literal("§6RealmForge Equipment\n§ePant: §f" + d.equipment.get("pant") + "\n§eShirt: §f" + d.equipment.get("shirt") + "\n§eHat: §f" + d.equipment.get("hat") + "\n§eShoes: §f" + d.equipment.get("shoes") + "\n§eWeapon: §f" + d.equipment.get("weapon") + "\n§7Set an item with /realmforge equip <slot> <item>"), false);
        return 1;
    }
    private static int equip(ServerCommandSource source, String rawSlot, String item) {
        if (!(source.getEntity() instanceof ServerPlayerEntity p)) return 0;
        String slot = rawSlot.toLowerCase(Locale.ROOT);
        if (!Set.of("pant", "shirt", "hat", "shoes", "weapon").contains(slot)) { source.sendError(Text.literal("Slot must be pant, shirt, hat, shoes, or weapon.")); return 0; }
        PlayerData d = get(p); d.equipment.put(slot, item); save(p.getServer()); sync(p);
        source.sendFeedback(() -> Text.literal("§aEquipped " + item + " in " + slot + "."), false); return 1;
    }
    private static int showMastery(ServerCommandSource source) {
        if (!(source.getEntity() instanceof ServerPlayerEntity p)) return 0;
        PlayerData d = get(p);
        StringBuilder out = new StringBuilder("§6Skill Mastery (max 300; 2000 mastery EXP per level)\n");
        for (String skill : SKILLS) out.append("§b").append(skill).append(" §fLv.").append(d.mastery.getOrDefault(skill, 0)).append(" §7EXP ").append(d.masteryXp.getOrDefault(skill, 0)).append("/2000\n");
        source.sendFeedback(() -> Text.literal(out.toString()), false); return 1;
    }

    private static void awardMastery(PlayerData d, String skill) {
        int level = d.mastery.getOrDefault(skill, 0);
        if (level >= 300) return;
        d.masteryXp.put(skill, d.masteryXp.getOrDefault(skill, 0) + 50);
        while (d.masteryXp.get(skill) >= 2000 && d.mastery.get(skill) < 300) {
            d.masteryXp.put(skill, d.masteryXp.get(skill) - 2000);
            d.mastery.put(skill, d.mastery.get(skill) + 1);
        }
        if (d.mastery.get(skill) >= 300) d.masteryXp.put(skill, 0);
    }

    private static int useSkill(ServerCommandSource source, String raw) {
        if (!(source.getEntity() instanceof ServerPlayerEntity p)) { source.sendError(Text.literal("Players only.")); return 0; }
        PlayerData d = get(p); String skill = raw.toLowerCase(Locale.ROOT);
        int cost = skill.equals("focus") ? 0 : skill.equals("burst") ? 10 : skill.equals("dash") ? 8 : skill.equals("nova") ? 25 : skill.equals("heal") ? 18 : skill.equals("guard") ? 12 : -1;
        if (cost < 0) { source.sendError(Text.literal("Unknown skill. Use burst, focus, dash, nova, heal, or guard.")); return 0; }
        if (d.perk.equals("Energy Saver") && cost > 0) cost = Math.max(1, cost * 80 / 100);
        if ((d.trait.equals("Mana Conduit") || d.perk.equals("Overcharger")) && cost > 0) cost = Math.max(1, (int)Math.ceil(cost * 1.10));
        if (skill.equals("focus")) d.energy = Math.min(d.maxEnergy(), d.energy + 15 + d.stats.get("INT") * 2);
        else {
            if (d.energy < cost) { source.sendError(Text.literal("Not enough energy: need " + cost + ".")); return 0; }
            d.energy -= cost;
            switch (skill) {
                case "burst" -> hitNearby(p, d, 3.5, 4 + d.stats.get("INT") * 0.8 + d.stats.get("STR") * 0.4, "burst");
                case "nova" -> hitNearby(p, d, 6, 10 + d.stats.get("INT") * 1.5, "nova");
                case "dash" -> { p.addVelocity(p.getRotationVector().multiply(1.5)); }
                case "heal" -> p.heal(6 + d.stats.get("INT") * 0.5f);
                case "guard" -> { p.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.RESISTANCE, 100, 1)); }
            }
        }
        awardMastery(d, skill);
        save(p.getServer()); sync(p); source.sendFeedback(() -> Text.literal("§bSkill used: §f" + skill + " §7(" + d.energy + "/" + d.maxEnergy() + " energy; mastery " + d.mastery.getOrDefault(skill, 0) + ")"), false); return 1;
    }

    private static void hitNearby(ServerPlayerEntity p, PlayerData d, double range, double base, String skill) {
        double damage = base + d.stats.get("INT") * 0.5;
        if (d.trait.equals("Arcane Soul")) damage *= 1.15;
        if (d.perk.equals("Heavy Hitter")) damage *= 1.2;
        if (d.perk.equals("Fleet Footed")) damage *= 0.90;
        damage *= 1.0 + d.mastery.getOrDefault(skill, 0) * 0.025;
        p.getWorld().getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(range), e -> e != p && !(e instanceof ServerPlayerEntity) && e.isAlive()).forEach(e -> e.damage(p.getDamageSources().playerAttack(p), (float)damage));
    }

    private static double gearBonus(String item) {
        if (item == null) return 0;
        String s = item.toLowerCase(Locale.ROOT);
        if (s.contains("mythic")) return 8;
        if (s.contains("legendary")) return 6;
        if (s.contains("netherite")) return 5;
        if (s.contains("diamond")) return 4;
        if (s.contains("iron")) return 3;
        if (s.contains("stone")) return 2;
        if (s.contains("wood")) return 1;
        return 0;
    }
    private static void applyAttributes(ServerPlayerEntity p, PlayerData d) {
        EntityAttributeInstance hp = p.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        int gearHp = gearBonus(d.equipment.getOrDefault("shirt", "None")) + gearBonus(d.equipment.getOrDefault("pant", "None")) + gearBonus(d.equipment.getOrDefault("hat", "None"));
        double maxHp = 20 + d.stats.get("VIT") * 4 + (d.trait.equals("Vital Core") ? 4 : 0) + (d.perk.equals("Deep Reserves") ? 2 : 0) + gearHp;
        if (d.trait.equals("Arcane Soul") || d.trait.equals("Duelist's Edge")) maxHp *= 0.90;
        if (d.perk.equals("Keen Eye")) maxHp *= 0.95;
        if (hp != null) hp.setBaseValue(Math.min(1024, Math.max(1, maxHp)));
        EntityAttributeInstance speed = p.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
        double shoeSpeed = gearBonus(d.equipment.getOrDefault("shoes", "None")) * 0.001;
        // Keep movement progression noticeable but capped; 0.0005 per AGI point.
        double move = 0.1 + d.stats.get("AGI") * 0.0005 + (d.trait.equals("Swift Current") ? 0.015 : 0) + (d.perk.equals("Fleet Footed") ? 0.015 : 0) + shoeSpeed;
        if (d.trait.equals("Iron Will") || d.trait.equals("Vital Core") || d.trait.equals("Unbreakable") || d.perk.equals("Heavy Hitter")) move *= 0.90;
        if (speed != null) speed.setBaseValue(Math.min(0.35, Math.max(0.01, move)));
    }

    private static void normalizeRank(PlayerData d) {
        d.rank = d.level >= 100 ? "Mythic" : d.level >= 75 ? "Legend" : d.level >= 50 ? "Diamond" : d.level >= 30 ? "Platinum" : d.level >= 15 ? "Gold" : d.level >= 5 ? "Silver" : "Novice";
    }
    public static PlayerData get(ServerPlayerEntity player) { return DATA.computeIfAbsent(player.getUuid(), id -> new PlayerData()); }
    private static String choose(String[] choices) { return choices[new Random().nextInt(choices.length)]; }
    private static void load(MinecraftServer server) {
        dataFile = server.getSavePath(WorldSavePath.ROOT).resolve("realmforge-playerdata.json"); DATA.clear();
        if (!Files.exists(dataFile)) return;
        try (Reader reader = Files.newBufferedReader(dataFile)) {
            Map<String, PlayerData> loaded = GSON.fromJson(reader, STORE_TYPE);
            if (loaded != null) loaded.forEach((id, d) -> { try { DATA.put(UUID.fromString(id), d.normalize()); } catch (IllegalArgumentException ignored) {} });
        } catch (Exception ex) { System.err.println("[RealmForge] Data load failed: " + ex.getMessage()); }
    }
    private static void save(MinecraftServer server) {
        if (server == null || dataFile == null) return;
        Path temp = dataFile.resolveSibling(dataFile.getFileName() + ".tmp");
        try {
            Files.createDirectories(dataFile.getParent());
            Map<String, PlayerData> copy = new HashMap<>();
            DATA.forEach((id, d) -> copy.put(id.toString(), d));
            try (Writer writer = Files.newBufferedWriter(temp)) { GSON.toJson(copy, writer); }
            try { Files.move(temp, dataFile, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
            catch (java.nio.file.AtomicMoveNotSupportedException ignored) { Files.move(temp, dataFile, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ex) { System.err.println("[RealmForge] Data save failed: " + ex.getMessage()); }
    }
    private static void sync(ServerPlayerEntity p) {
        try { ServerPlayNetworking.send(p, new RealmForgeSyncPayload(GSON.toJson(SyncData.from(p, get(p))))); }
        catch (Exception ignored) { }
    }
    public static final class SyncData {
        public String name, rank, trait, perk;
        public int level, xp, xpMax, points, energy, energyMax, hp, hpMax;
        public Map<String, Integer> stats, mastery, masteryXp;
        public Map<String, String> equipment;
        public List<String> slots;
        static SyncData from(ServerPlayerEntity p, PlayerData d) {
            SyncData s = new SyncData(); s.name = p.getName().getString(); s.rank = d.rank; s.trait = d.trait; s.perk = d.perk;
            s.level = d.level; s.xp = d.xp; s.xpMax = d.xpToNext(); s.points = d.statPoints; s.energy = d.energy; s.energyMax = d.maxEnergy(); s.hp = (int)p.getHealth(); s.hpMax = (int)p.getMaxHealth();
            s.stats = new HashMap<>(d.stats); s.mastery = new HashMap<>(d.mastery); s.masteryXp = new HashMap<>(d.masteryXp); s.equipment = new HashMap<>(d.equipment); s.slots = new ArrayList<>(d.skillSlots); return s;
        }
    }
    public static final class PlayerData {
        public int level = 1, xp = 0, statPoints = 0, energy = 3, secondWindCooldown = 0;
        public String rank = "Novice", trait = "", perk = "";
        public Map<String, Integer> stats = new HashMap<>();
        public Map<String, Integer> mastery = new HashMap<>(), masteryXp = new HashMap<>();
        public Map<String, String> equipment = new HashMap<>();
        public List<String> skillSlots = new ArrayList<>(List.of("burst", "focus", "dash", "nova", "heal", "guard"));
        public PlayerData() {
            for (String s : List.of("STR", "AGI", "VIT", "INT", "ENE")) stats.put(s, 0);
            for (String s : SKILLS) { mastery.put(s, 0); masteryXp.put(s, 0); }
            for (String s : List.of("pant", "shirt", "hat", "shoes", "weapon")) equipment.put(s, "None");
        }
        public PlayerData normalize() {
            if (stats == null) stats = new HashMap<>(); for (String s : List.of("STR", "AGI", "VIT", "INT", "ENE")) { if (stats.get(s) == null) stats.put(s, 0); stats.put(s, Math.max(0, stats.get(s))); }
            if (mastery == null) mastery = new HashMap<>(); if (masteryXp == null) masteryXp = new HashMap<>();
            for (String s : SKILLS) { if (mastery.get(s) == null) mastery.put(s, 0); if (masteryXp.get(s) == null) masteryXp.put(s, 0); mastery.put(s, Math.max(0, Math.min(300, mastery.get(s)))); masteryXp.put(s, Math.max(0, masteryXp.get(s))); }
            if (equipment == null) equipment = new HashMap<>(); for (String s : List.of("pant", "shirt", "hat", "shoes", "weapon")) equipment.putIfAbsent(s, "None");
            if (skillSlots == null) skillSlots = new ArrayList<>(List.of("burst", "focus", "dash", "nova", "heal", "guard"));
            while (skillSlots.size() < 6) skillSlots.add(SKILLS[skillSlots.size()]); if (skillSlots.size() > 6) skillSlots = new ArrayList<>(skillSlots.subList(0, 6));
            for (int i = 0; i < skillSlots.size(); i++) if (skillSlots.get(i) == null || !Arrays.asList(SKILLS).contains(skillSlots.get(i))) skillSlots.set(i, SKILLS[i]);
            level = Math.max(1, level); xp = Math.max(0, xp); statPoints = Math.max(0, statPoints); if (energy < 0) energy = 0; secondWindCooldown = Math.max(0, secondWindCooldown);
            if (rank == null) rank = "Novice"; if (trait == null) trait = ""; if (perk == null) perk = ""; energy = Math.min(energy, maxEnergy()); return this;
        }
        public int maxEnergy() { int max = 3 + stats.getOrDefault("ENE", 0) * 5 + (perk.equals("Deep Reserves") ? 25 : 0); return Math.max(3, perk.equals("Guardian") || trait.equals("Predator's Focus") ? (int)Math.floor(max * 0.90) : max); }
        public int xpToNext() { return 100 + (level - 1) * 25; }
    }
}
