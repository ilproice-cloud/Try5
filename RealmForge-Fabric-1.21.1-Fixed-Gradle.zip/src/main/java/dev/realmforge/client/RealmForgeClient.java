package dev.realmforge.client;

import com.google.gson.Gson;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;
import dev.realmforge.RealmForge;
import dev.realmforge.RealmForgeSyncPayload;

public final class RealmForgeClient implements ClientModInitializer {
    private static final Gson GSON = new Gson();
    public static RealmForge.SyncData snapshot;
    private KeyBinding openBook;
    private final KeyBinding[] skillKeys = new KeyBinding[6];

    @Override public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(RealmForgeSyncPayload.ID, (payload, context) -> {
            RealmForge.SyncData parsed = GSON.fromJson(payload.json(), RealmForge.SyncData.class);
            context.client().execute(() -> snapshot = parsed);
        });
        openBook = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.realmforge.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "category.realmforge"));
        int[] keys = {GLFW.GLFW_KEY_Z, GLFW.GLFW_KEY_X, GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_V, GLFW.GLFW_KEY_B, GLFW.GLFW_KEY_N};
        for (int i = 0; i < keys.length; i++) skillKeys[i] = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.realmforge.skill" + (i + 1), InputUtil.Type.KEYSYM, keys[i], "category.realmforge"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openBook.wasPressed()) if (client.player != null && client.currentScreen == null) client.setScreen(new RealmForgeBookScreen());
            if (client.player != null && client.getNetworkHandler() != null) {
                for (int i = 0; i < skillKeys.length; i++) while (skillKeys[i].wasPressed()) client.getNetworkHandler().sendChatCommand("realmforge cast " + (i + 1));
            }
        });
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> renderHud(MinecraftClient.getInstance(), drawContext));
    }

    private void renderHud(MinecraftClient client, DrawContext c) {
        if (client.player == null || client.options.hudHidden || snapshot == null || client.currentScreen instanceof RealmForgeBookScreen) return;
        int x = 7, y = 7, w = 118;
        c.fill(x - 2, y - 2, x + w + 2, y + 70, 0x990e0b16);
        c.drawTextWithShadow(client.textRenderer, Text.literal("REALMFORGE · Lv " + snapshot.level).formatted(Formatting.GOLD), x, y, 0xffffffff);
        bar(c, x, y + 13, w, 5, snapshot.hp, snapshot.hpMax, 0xffd83c4b);
        bar(c, x, y + 22, w, 5, snapshot.xp, snapshot.xpMax, 0xff54bd65);
        bar(c, x, y + 31, w, 5, snapshot.energy, snapshot.energyMax, 0xff4d9ee8);
        c.drawTextWithShadow(client.textRenderer, Text.literal("HP " + snapshot.hp + "/" + snapshot.hpMax), x, y + 39, 0xffffffff);
        c.drawTextWithShadow(client.textRenderer, Text.literal("Energy " + snapshot.energy + "/" + snapshot.energyMax), x + 58, y + 39, 0xffb8e3ff);
    }
    private static void bar(DrawContext c, int x, int y, int w, int h, int value, int max, int color) {
        c.fill(x, y, x + w, y + h, 0xff3a3340);
        int fill = (int)(w * Math.max(0, Math.min(1, value / (double)Math.max(1, max))));
        if (fill > 0) c.fill(x, y, x + fill, y + h, color);
    }
}
